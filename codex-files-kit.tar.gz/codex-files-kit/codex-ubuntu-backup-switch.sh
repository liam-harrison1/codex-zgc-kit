#!/usr/bin/env bash
set -euo pipefail

mkdir -p "$HOME/.codex" "$HOME/.local/bin"
export PATH="$HOME/.local/bin:$PATH"

if ! grep -qs 'HOME/.local/bin' "$HOME/.bashrc" 2>/dev/null; then
  printf '\nexport PATH="$HOME/.local/bin:$PATH"\n' >> "$HOME/.bashrc"
fi

write_capi() {
  mkdir -p "$HOME/.codex"
  if [ ! -f "$HOME/.codex/auth.json" ]; then
    echo "WARN: ~/.codex/auth.json not found. capi needs your activation key there."
  fi

  cp "$HOME/.codex/config.toml" "$HOME/.codex/config.toml.bak.$(date +%Y%m%d-%H%M%S)" 2>/dev/null || true
  cat > "$HOME/.codex/config.toml" <<'EOF'
model_provider = "OpenAI"
model = "gpt-5.4"
review_model = "gpt-5.4"
model_reasoning_effort = "high"
disable_response_storage = true

[model_providers.OpenAI]
name = "OpenAI"
base_url = "https://capi.quan2go.com/openai"
wire_api = "responses"
requires_openai_auth = true
EOF
  chmod 600 "$HOME/.codex/config.toml" 2>/dev/null || true
  echo "OK: switched to capi.quan2go.com"
}

write_sub2api() {
  mkdir -p "$HOME/.codex"
  if [ ! -s "$HOME/.codex/sub2api-key" ]; then
    echo "ERROR: ~/.codex/sub2api-key not found."
    echo "This backup needs the sub2api key file created earlier."
    exit 1
  fi

  cp "$HOME/.codex/config.toml" "$HOME/.codex/config.toml.bak.$(date +%Y%m%d-%H%M%S)" 2>/dev/null || true
  cat > "$HOME/.codex/config.toml" <<'EOF'
model = "gpt-5.5"
model_provider = "sub2api-local"
model_reasoning_effort = "medium"
disable_response_storage = true

[model_providers.sub2api-local]
name = "Sub2API Cloudflare"
base_url = "https://meal-anna-processes-selective.trycloudflare.com/v1"
wire_api = "responses"
requires_openai_auth = false
supports_websockets = false
request_max_retries = 2
stream_max_retries = 5
stream_idle_timeout_ms = 600000

[model_providers.sub2api-local.auth]
command = "/bin/sh"
args = ["-lc", "cat \"$HOME/.codex/sub2api-key\""]
refresh_interval_ms = 0
timeout_ms = 1000
EOF
  chmod 600 "$HOME/.codex/config.toml" "$HOME/.codex/sub2api-key" 2>/dev/null || true
  echo "OK: switched to sub2api/cloudflare"
}

write_test() {
  cat > "$HOME/.local/bin/codex-test" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
export PATH="$HOME/.local/bin:$PATH"
echo "base_url:"
grep -n 'base_url' "$HOME/.codex/config.toml" || true
echo
codex exec --skip-git-repo-check --ephemeral "reply exactly: OK"
EOF
  chmod +x "$HOME/.local/bin/codex-test"
}

cat > "$HOME/.local/bin/codex-use-capi" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$HOME/.codex"
if [ ! -f "$HOME/.codex/auth.json" ]; then
  echo "WARN: ~/.codex/auth.json not found. capi needs your activation key there."
fi
cp "$HOME/.codex/config.toml" "$HOME/.codex/config.toml.bak.$(date +%Y%m%d-%H%M%S)" 2>/dev/null || true
cat > "$HOME/.codex/config.toml" <<'CONFIG'
model_provider = "OpenAI"
model = "gpt-5.4"
review_model = "gpt-5.4"
model_reasoning_effort = "high"
disable_response_storage = true

[model_providers.OpenAI]
name = "OpenAI"
base_url = "https://capi.quan2go.com/openai"
wire_api = "responses"
requires_openai_auth = true
CONFIG
chmod 600 "$HOME/.codex/config.toml" 2>/dev/null || true
echo "OK: switched to capi.quan2go.com"
EOF

cat > "$HOME/.local/bin/codex-use-sub2api" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$HOME/.codex"
if [ ! -s "$HOME/.codex/sub2api-key" ]; then
  echo "ERROR: ~/.codex/sub2api-key not found."
  echo "This backup needs the sub2api key file created earlier."
  exit 1
fi
cp "$HOME/.codex/config.toml" "$HOME/.codex/config.toml.bak.$(date +%Y%m%d-%H%M%S)" 2>/dev/null || true
cat > "$HOME/.codex/config.toml" <<'CONFIG'
model = "gpt-5.5"
model_provider = "sub2api-local"
model_reasoning_effort = "medium"
disable_response_storage = true

[model_providers.sub2api-local]
name = "Sub2API Cloudflare"
base_url = "https://meal-anna-processes-selective.trycloudflare.com/v1"
wire_api = "responses"
requires_openai_auth = false
supports_websockets = false
request_max_retries = 2
stream_max_retries = 5
stream_idle_timeout_ms = 600000

[model_providers.sub2api-local.auth]
command = "/bin/sh"
args = ["-lc", "cat \"$HOME/.codex/sub2api-key\""]
refresh_interval_ms = 0
timeout_ms = 1000
CONFIG
chmod 600 "$HOME/.codex/config.toml" "$HOME/.codex/sub2api-key" 2>/dev/null || true
echo "OK: switched to sub2api/cloudflare"
EOF

case "${1:-install}" in
  capi)
    write_capi
    ;;
  sub2api)
    write_sub2api
    ;;
  install)
    write_test
    chmod +x "$HOME/.local/bin/codex-use-capi" "$HOME/.local/bin/codex-use-sub2api"
    echo "Installed:"
    echo "  codex-use-capi"
    echo "  codex-use-sub2api"
    echo "  codex-test"
    echo
    echo "Use:"
    echo "  codex-use-capi      # main route"
    echo "  codex-use-sub2api   # backup route via your Mac Cloudflare"
    echo "  codex-test          # quick OK test"
    ;;
  *)
    echo "Usage: $0 [install|capi|sub2api]"
    exit 2
    ;;
esac
