#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

mkdir -p "$HOME/.codex" "$HOME/.local/bin"

ts="$(date +%Y%m%d-%H%M%S)"
if [ -d "$HOME/.codex/skills" ]; then
  mv "$HOME/.codex/skills" "$HOME/.codex/skills.bak.$ts"
fi

cp -R ./skills "$HOME/.codex/skills"

if [ -f ./codex-ubuntu-backup-switch.sh ]; then
  bash ./codex-ubuntu-backup-switch.sh
fi

echo "OK: installed Codex skills and switch commands."
echo
echo "Next commands:"
echo "  codex-use-capi"
echo "  codex-use-sub2api"
echo "  codex-test"
