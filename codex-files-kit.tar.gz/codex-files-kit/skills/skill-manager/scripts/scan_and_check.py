#!/usr/bin/env python3
import concurrent.futures
import json
import os
import re
import subprocess
import sys

try:
    import yaml
except ModuleNotFoundError:
    yaml = None

FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---", re.DOTALL)


def strip_quotes(value):
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
        return value[1:-1]
    return value


def parse_frontmatter_fallback(raw):
    """Parse the simple top-level YAML fields needed by the scanner."""
    meta = {}
    lines = raw.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip() or line.lstrip().startswith("#") or line.startswith((" ", "\t", "-")):
            i += 1
            continue
        if ":" not in line:
            i += 1
            continue
        key, value = line.split(":", 1)
        key = key.strip()
        value = value.strip()
        if value in {">", ">-", ">+", "|", "|-", "|+"}:
            block = []
            i += 1
            while i < len(lines):
                nxt = lines[i]
                if nxt.startswith((" ", "\t")) or not nxt.strip():
                    block.append(nxt.strip())
                    i += 1
                    continue
                break
            if value.startswith("|"):
                meta[key] = "\n".join(block).strip()
            else:
                meta[key] = " ".join(part for part in block if part).strip()
            continue
        meta[key] = strip_quotes(value)
        i += 1
    return meta


def read_metadata(skill_md):
    content = open(skill_md, "r", encoding="utf-8").read()
    match = FRONTMATTER_RE.match(content)
    if not match:
        return {}
    raw = match.group(1)
    if yaml is not None:
        try:
            parsed = yaml.safe_load(raw)
            if isinstance(parsed, dict):
                return parsed
        except Exception:
            pass
    return parse_frontmatter_fallback(raw)


def get_remote_hash(url):
    """Fetch the latest commit hash from the remote repository."""
    try:
        result = subprocess.run(
            ["git", "ls-remote", url, "HEAD"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return None
        parts = result.stdout.split()
        return parts[0] if parts else None
    except Exception:
        return None


def scan_skills(skills_root):
    """Scan subdirectories for GitHub-managed SKILL.md metadata."""
    skill_list = []

    if not os.path.exists(skills_root):
        print(f"Skills root not found: {skills_root}", file=sys.stderr)
        return []

    for item in sorted(os.listdir(skills_root)):
        skill_dir = os.path.join(skills_root, item)
        if not os.path.isdir(skill_dir):
            continue

        skill_md = os.path.join(skill_dir, "SKILL.md")
        if not os.path.exists(skill_md):
            continue

        try:
            frontmatter = read_metadata(skill_md)
            if "github_url" in frontmatter:
                skill_list.append({
                    "name": frontmatter.get("name", item),
                    "dir": skill_dir,
                    "github_url": frontmatter["github_url"],
                    "local_hash": frontmatter.get("github_hash", "unknown"),
                    "local_version": frontmatter.get("version", "0.0.0"),
                })
        except Exception as exc:
            print(f"Skipping {skill_md}: {exc}", file=sys.stderr)

    return skill_list


def check_updates(skills):
    """Check for updates concurrently."""
    results = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        future_to_skill = {
            executor.submit(get_remote_hash, skill["github_url"]): skill
            for skill in skills
        }

        for future in concurrent.futures.as_completed(future_to_skill):
            skill = future_to_skill[future]
            try:
                remote_hash = future.result()
                skill["remote_hash"] = remote_hash

                if not remote_hash:
                    skill["status"] = "error"
                    skill["message"] = "Could not reach remote"
                elif remote_hash != skill["local_hash"]:
                    skill["status"] = "outdated"
                    skill["message"] = "New commits available"
                else:
                    skill["status"] = "current"
                    skill["message"] = "Up to date"

                results.append(skill)
            except Exception as exc:
                skill["status"] = "error"
                skill["message"] = str(exc)
                results.append(skill)

    return results


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python scan_and_check.py <skills_dir>")
        sys.exit(1)

    skills = scan_skills(sys.argv[1])
    updates = check_updates(skills)
    print(json.dumps(updates, indent=2, ensure_ascii=False))
