#!/usr/bin/env python3
import io
import os
import re
import sys

try:
    import yaml
except ModuleNotFoundError:
    yaml = None

# Force UTF-8 encoding for stdout to handle non-ASCII descriptions.
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
else:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---", re.DOTALL)


def strip_quotes(value):
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
        return value[1:-1]
    return value


def parse_frontmatter_fallback(raw):
    """Parse the simple top-level YAML fields skills need without PyYAML."""
    meta = {}
    lines = raw.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip() or line.lstrip().startswith("#") or line.startswith((" ", "\t", "-")):
            i += 1
            continue
        if ":" not in line:
            i += 1
            continue
        key, value = line.split(":", 1)
        key = key.strip()
        value = value.strip()
        if value in {">", ">-", ">+", "|", "|-", "|+"}:
            block = []
            i += 1
            while i < len(lines):
                nxt = lines[i]
                if nxt.startswith((" ", "\t")) or not nxt.strip():
                    block.append(nxt.strip())
                    i += 1
                    continue
                break
            if value.startswith("|"):
                meta[key] = "\n".join(block).strip()
            else:
                meta[key] = " ".join(part for part in block if part).strip()
            continue
        meta[key] = strip_quotes(value)
        i += 1
    return meta


def read_metadata(skill_md):
    content = open(skill_md, "r", encoding="utf-8").read()
    match = FRONTMATTER_RE.match(content)
    if not match:
        return {}
    raw = match.group(1)
    if yaml is not None:
        try:
            parsed = yaml.safe_load(raw)
            if isinstance(parsed, dict):
                return parsed
        except Exception:
            pass
    return parse_frontmatter_fallback(raw)


def list_skills(skills_root):
    if not os.path.exists(skills_root):
        print(f"Error: {skills_root} not found")
        return

    header = f"{'Skill Name':<28} | {'Type':<12} | {'Description':<40} | {'Ver':<8}"
    print(header)
    print("-" * len(header))

    for item in sorted(os.listdir(skills_root)):
        skill_dir = os.path.join(skills_root, item)
        if not os.path.isdir(skill_dir):
            continue

        skill_md = os.path.join(skill_dir, "SKILL.md")
        if not os.path.exists(skill_md):
            continue

        skill_type = "Standard"
        version = "0.1.0"
        description = "No description"

        try:
            meta = read_metadata(skill_md)
            if "github_url" in meta:
                skill_type = "GitHub"
            version = str(meta.get("version", "0.1.0"))
            description = str(meta.get("description", "No description")).replace("\n", " ")
        except Exception as exc:
            description = f"Metadata error: {exc}"

        display_desc = description[:37] + "..." if len(description) > 37 else description
        print(f"{item:<28} | {skill_type:<12} | {display_desc:<40} | {version:<8}")


if __name__ == "__main__":
    skills_path = os.path.expanduser("~/.codex/skills")
    if len(sys.argv) > 1:
        skills_path = sys.argv[1]
    list_skills(skills_path)
