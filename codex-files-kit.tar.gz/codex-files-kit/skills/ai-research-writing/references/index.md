# Reference Index

Source: https://github.com/Leey21/awesome-ai-research-writing

- `polish-english-paper.md`: 表达润色（英文论文）
- `polish-chinese-paper.md`: 表达润色（中文论文）
- `logic-check.md`: 逻辑检查
- `anti-ai-latex-english.md`: 去 AI 味（LaTeX 英文）
- `anti-ai-word-chinese.md`: 去 AI 味（Word 中文）
- `paper-architecture-figure.md`: 论文架构图
- `experiment-figure-recommendation.md`: 实验绘图推荐
- `figure-title.md`: 生成图的标题
- `table-title.md`: 生成表的标题
- `experiment-analysis.md`: 实验分析
- `reviewer-perspective-review.md`: 论文整体以 Reviewer 视角进行审视
- `model-selection.md`: 模型选择
