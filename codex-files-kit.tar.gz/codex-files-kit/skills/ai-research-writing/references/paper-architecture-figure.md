# 论文架构图

Source: Leey21/awesome-ai-research-writing README.md

````markdown
# Role
你是一位世界顶尖的学术插画专家，专注于为计算机视觉与人工智能领域的顶级会议（如 CVPR, NeurIPS, ICLR）绘制高质量、直观且美观的论文架构图。

# Task
请阅读我提供的【论文方法描述】，首先深刻理解其核心机制、模块组成和数据流向。然后，基于你的理解，设计并绘制一张专业的学术架构图。

# Visual Constraints
1. 风格基调：
   - 必须具备顶会论文风格：专业、干净、现代、极简主义。
   - 核心美学：采用扁平化矢量插画风格，线条简洁，参考 DeepMind 或 OpenAI 论文中的图表美学。
   - 拒绝卡通感、油画感或过度艺术化，保持严谨的学术图表美学。
   - 背景必须是纯白色，无任何纹理或阴影。

2. 色彩体系：
   - 严格使用淡色系或柔和色调。
   - 严禁使用过于鲜艳饱和的颜色（如大红大绿）或过于暗淡沉重的颜色。利用颜色的深浅变化来区分不同的模块类型。

3. 内容与布局：
   - 将理解到的方法论转化为清晰的模块和数据流箭头。
   - 适当使用现代、简洁的矢量图标嵌入到模块中，以增强直观性。

4. 文字规范：
   - 图中所有文字必须使用英文。
   - 你必须为方法论中提到的关键模块或方程式添加清晰易读的文本标签。
   - 严禁在图中出现长句子、描述性段落或复杂的公式。文字是用来说明模块身份的，不是用来解释原理的。

5. 禁止事项：
   - 不允许使用逼真照片感。
   - 不允许杂乱的草图线条。
   - 不允许难以辨认的文本。
   - 不允许廉价的 3D 阴影瑕疵。

# Input Methodology
[在此处粘贴你的论文摘要(Abs) + 方法部分描述]
````

多人反馈，在调用nano banana时，使用下面的英文版本的prompt效果会更好（可能与nano banana训练数据有关），建议使用时中英文版本都可以进行尝试，根据自己的审美取最优：

````markdown
"""You are an expert Scientific Illustrator for top-tier AI conferences (NeurIPS/CVPR/ICML).
Your task is to generate a professional "Illustration" (main figure for the paper) based on a research paper abstract and methodology.

**Abstract:**
{abstract}

**Methodology:**
{methodology}

**Visual Style Requirements:**
1.  **Style:** Flat vector illustration, clean lines, academic aesthetic. Similar to figures in DeepMind or OpenAI papers.
2.  **Layout:** Organized flow (Left-to-Right, Top-to-Bottom, Circular and other shapes). Group related components logically.
3.  **Color Palette:** Professional pastel tones. White background.
4.  **Text Rendering:** You MUST include legible text labels for key modules or equations mentioned in the methodology (e.g., "Encoder", "Loss", "Transformer").
5.  **Negative Constraints:** NO photorealistic photos, NO messy sketches, NO unreadable text, NO 3D shading artifacts.

**Generation Instruction:**
Highlight the core novelty. Ensure the connection logic makes sense."""
````
![由上述prompt生成的效果图](images/nano-banana.png)

---
