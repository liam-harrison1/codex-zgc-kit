---
name: ai-research-writing
description: >
  Academic paper writing helper for English/Chinese polishing, logic checks,
  AI-style reduction, figure/table titles, experiment analysis, reviewer-style
  review, and model-selection guidance.
---

# AI Research Writing

This skill packages selected workflows from `Leey21/awesome-ai-research-writing` into one router-style skill. Load only the reference file that matches the current task.

## Route The Task

Open the relevant file from `references/`:

| User intent | Reference file |
| --- | --- |
| English paper polishing, LaTeX academic English refinement | `references/polish-english-paper.md` |
| Chinese paper polishing for Word or Chinese manuscripts | `references/polish-chinese-paper.md` |
| Logic check, terminology consistency, contradiction detection | `references/logic-check.md` |
| Remove AI-like style from English LaTeX writing | `references/anti-ai-latex-english.md` |
| Remove AI-like style from Chinese Word-style writing | `references/anti-ai-word-chinese.md` |
| Generate a paper architecture / framework figure prompt | `references/paper-architecture-figure.md` |
| Recommend chart types for experiment results | `references/experiment-figure-recommendation.md` |
| Generate an English figure title | `references/figure-title.md` |
| Generate an English table title | `references/table-title.md` |
| Write LaTeX experiment analysis from numeric results | `references/experiment-analysis.md` |
| Review the whole paper from a reviewer perspective | `references/reviewer-perspective-review.md` |
| Select a model or compare model choices | `references/model-selection.md` |

If the task mixes several intents, handle them in the natural order. For example, for "帮我检查逻辑然后去 AI 味", use `logic-check.md` first, then the appropriate anti-AI reference.

## Working Rules

1. Preserve the user's target format. If the input is LaTeX, keep LaTeX commands, citations, labels, math, and escaping intact.
2. Do not invent experimental results, citations, or claims. If evidence is missing, mark it as missing instead of filling it in.
3. For polishing tasks, prefer conservative edits over rewriting the author's argument.
4. For reviewer-perspective review, lead with blocking issues and claim-evidence gaps.
5. For figure and table titles, output only the requested title unless the user asks for alternatives or explanation.

## Source

Selected sections are copied from:

- `https://github.com/Leey21/awesome-ai-research-writing`

See `references/index.md` for the extracted section list.
