import argparse
import json
import math
import random
import sys
import zipfile
from pathlib import Path

SCRIPT_PATH = Path(__file__).resolve()
POTENTIAL_VENDOR_DIRS = [
    SCRIPT_PATH.parents[2] / ".vendor-pptx",
    Path.cwd() / ".vendor-pptx",
    SCRIPT_PATH.parent / ".vendor-pptx",
]

for vendor_dir in POTENTIAL_VENDOR_DIRS:
    if vendor_dir.exists():
        sys.path.insert(0, str(vendor_dir))
        break

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
from pptx.enum.text import MSO_VERTICAL_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt


DEFAULT_OUTPUT_NAME = "FA-SAETR_flowchart_recreated_v2.pptx"
DEFAULT_TITLE = "FA-SAETR: Feature-Attentive Sparse Autoencoder Transformer for Battery Remaining Useful Life Prediction"


def rgb(value: str) -> RGBColor:
    return RGBColor.from_string(value.replace("#", "").upper())


def set_font(run, *, name="Times New Roman", size=12, bold=False, italic=False, color="000000"):
    font = run.font
    font.name = name
    font.size = Pt(size)
    font.bold = bold
    font.italic = italic
    font.color.rgb = rgb(color)


def style_line(line, color="333333", width=1.2, dash=None):
    line.color.rgb = rgb(color)
    line.width = Pt(width)
    if dash is not None:
        line.dash_style = dash


def style_fill(fill, color_hex, transparency=None):
    fill.solid()
    fill.fore_color.rgb = rgb(color_hex)
    if transparency is not None:
        fill.transparency = transparency


def add_textbox(slide, x, y, w, h, lines, *, align=PP_ALIGN.CENTER, anchor=MSO_VERTICAL_ANCHOR.MIDDLE,
                margin=4, fill=None, line=None, rounded=False):
    shape_type = MSO_SHAPE.ROUNDED_RECTANGLE if rounded else MSO_SHAPE.RECTANGLE
    shape = slide.shapes.add_shape(shape_type, Inches(x), Inches(y), Inches(w), Inches(h))
    if fill:
        color_hex, transparency = fill if isinstance(fill, tuple) else (fill, None)
        style_fill(shape.fill, color_hex, transparency)
    else:
        shape.fill.background()
    if line:
        color_hex, width, dash = line
        style_line(shape.line, color_hex, width, dash)
    else:
        shape.line.fill.background()

    tf = shape.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.margin_left = Pt(margin)
    tf.margin_right = Pt(margin)
    tf.margin_top = Pt(margin)
    tf.margin_bottom = Pt(margin)
    tf.vertical_anchor = anchor

    for idx, spec in enumerate(lines):
        p = tf.paragraphs[0] if idx == 0 else tf.add_paragraph()
        p.alignment = align
        run = p.add_run()
        run.text = spec["text"]
        set_font(
            run,
            name=spec.get("font", "Times New Roman"),
            size=spec.get("size", 12),
            bold=spec.get("bold", False),
            italic=spec.get("italic", False),
            color=spec.get("color", "000000"),
        )
        p.space_before = Pt(spec.get("space_before", 0))
        p.space_after = Pt(spec.get("space_after", 0))
    return shape


def add_round_box(slide, x, y, w, h, fill_hex, *, line_hex="444444", line_width=1.2,
                  dash=None, radius_adjust=None, transparency=None):
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
    style_fill(shape.fill, fill_hex, transparency)
    style_line(shape.line, line_hex, line_width, dash)
    if radius_adjust is not None:
        try:
            shape.adjustments[0] = radius_adjust
        except Exception:
            pass
    return shape


def add_rect(slide, x, y, w, h, fill_hex, *, line_hex="444444", line_width=1.0, dash=None, transparency=None):
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
    style_fill(shape.fill, fill_hex, transparency)
    style_line(shape.line, line_hex, line_width, dash)
    return shape


def add_oval(slide, x, y, w, h, fill_hex="FFFFFF", *, line_hex="444444", line_width=1.0, transparency=None):
    shape = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x), Inches(y), Inches(w), Inches(h))
    style_fill(shape.fill, fill_hex, transparency)
    style_line(shape.line, line_hex, line_width)
    return shape


def add_arrow(slide, x1, y1, x2, y2, *, color="222222", width=1.4, begin=None, end=True):
    conn = slide.shapes.add_connector(
        MSO_CONNECTOR.STRAIGHT, Inches(x1), Inches(y1), Inches(x2), Inches(y2)
    )
    style_line(conn.line, color, width)
    if end:
        size = 0.08 if width <= 1.0 else 0.1
        arrow = slide.shapes.add_shape(
            MSO_SHAPE.ISOSCELES_TRIANGLE,
            Inches(x2 - size / 2),
            Inches(y2 - size / 2),
            Inches(size),
            Inches(size),
        )
        style_fill(arrow.fill, color)
        arrow.line.fill.background()
        angle = math.degrees(math.atan2(y2 - y1, x2 - x1)) + 90
        arrow.rotation = angle
    return conn


def draw_polyline(slide, points, *, color="6F8FA3", width=1.1):
    for (x1, y1), (x2, y2) in zip(points, points[1:]):
        add_arrow(slide, x1, y1, x2, y2, color=color, width=width, end=None)


def add_title(slide, title_text):
    add_textbox(
        slide, 0.18, 0.06, 13.64, 0.42,
        [
            {
                "text": title_text,
                "size": 20,
                "bold": True,
            }
        ],
        margin=1,
    )


def add_phase_container(slide, x, y, w, h, fill_hex, title):
    add_round_box(slide, x, y, w, h, fill_hex, line_hex="CFCFCF", line_width=1.0, radius_adjust=0.08)
    add_textbox(
        slide, x + 1.3, y + 0.08, w - 2.6, 0.38,
        [{"text": title, "size": 24, "bold": True}],
        margin=0,
    )


def add_dashed_panel(slide, x, y, w, h, title, fill_hex, *, title_size=16):
    panel = add_round_box(
        slide, x, y, w, h, fill_hex,
        line_hex="444444",
        line_width=1.1,
        dash=MSO_LINE_DASH_STYLE.DASH,
        radius_adjust=0.12,
    )
    add_textbox(
        slide, x + 0.1, y + 0.06, w - 0.2, 0.34,
        [{"text": title, "size": title_size, "bold": True}],
        margin=0,
    )
    return panel


def draw_axes(slide, x, y, w, h, *, xlabel=None, ylabel=None):
    add_arrow(slide, x, y + h, x + w, y + h, color="222222", width=1.0, end=True)
    add_arrow(slide, x, y + h, x, y, color="222222", width=1.0, end=True)
    if xlabel:
        add_textbox(slide, x + w * 0.35, y + h + 0.02, w * 0.5, 0.22, [{"text": xlabel, "size": 9}], margin=0)
    if ylabel:
        box = add_textbox(slide, x - 0.22, y + h * 0.2, 0.22, h * 0.55, [{"text": ylabel, "size": 9}], margin=0)
        box.rotation = 270


def draw_battery(slide, x, y, w=0.22, h=0.42, fill_hex="BFD7D8"):
    body = add_rect(slide, x, y, w, h, fill_hex, line_hex="444444", line_width=0.9)
    body.line.width = Pt(0.9)
    add_rect(slide, x + w * 0.33, y - 0.035, w * 0.34, 0.04, "444444", line_hex="444444", line_width=0)
    add_rect(slide, x + 0.03, y + 0.05, w - 0.06, h - 0.1, "FFFFFF", line_hex="FFFFFF", line_width=0)
    add_rect(slide, x + 0.03, y + 0.16, w - 0.06, h - 0.21, fill_hex, line_hex=fill_hex, line_width=0)
    return body


def draw_clipboard(slide, x, y, w=0.34, h=0.42):
    add_round_box(slide, x, y, w, h, "DCE9E9", line_hex="444444", line_width=0.9)
    add_round_box(slide, x + 0.11, y - 0.04, 0.12, 0.08, "9BAFB2", line_hex="444444", line_width=0.8)
    for i in range(3):
        add_arrow(slide, x + 0.07, y + 0.1 + i * 0.09, x + 0.18, y + 0.1 + i * 0.09, color="555555", width=0.8, end=None)
        dot = add_oval(slide, x + 0.04, y + 0.085 + i * 0.09, 0.02, 0.02, "89A3A6", line_hex="89A3A6", line_width=0)
        dot.line.fill.background()
    add_arrow(slide, x + 0.21, y + 0.22, x + 0.28, y + 0.31, color="688B91", width=1.0, end=True)
    add_arrow(slide, x + 0.28, y + 0.31, x + 0.31, y + 0.22, color="688B91", width=1.0, end=True)


def draw_clock(slide, x, y, r=0.14):
    add_oval(slide, x, y, r * 2, r * 2, "FFF7D1", line_hex="444444", line_width=0.9)
    cx = x + r
    cy = y + r
    add_arrow(slide, cx, cy, cx, cy - r * 0.55, color="444444", width=0.9, end=None)
    add_arrow(slide, cx, cy, cx + r * 0.45, cy + r * 0.12, color="444444", width=0.9, end=None)
    for ang in [0, 90, 180, 270]:
        px = cx + math.cos(math.radians(ang)) * r * 0.78
        py = cy - math.sin(math.radians(ang)) * r * 0.78
        add_oval(slide, px - 0.01, py - 0.01, 0.02, 0.02, "444444", line_hex="444444", line_width=0)


def draw_tiny_plot(slide, x, y, w, h, *, bg="FBF4EE", line_colors=("8FA5B9", "CF907C"), show_axes=False):
    add_rect(slide, x, y, w, h, bg, line_hex="C9B49A", line_width=0.8)
    if show_axes:
        draw_axes(slide, x + 0.05, y + 0.06, w - 0.1, h - 0.1)
    pts1 = []
    pts2 = []
    for i in range(7):
        px = x + 0.05 + i * (w - 0.1) / 6
        pts1.append((px, y + h * (0.2 + 0.1 * math.sin(i / 1.3) + i * 0.03)))
        pts2.append((px, y + h * (0.6 - 0.06 * i + 0.05 * math.cos(i / 1.2))))
    draw_polyline(slide, pts1, color=line_colors[0], width=1.0)
    draw_polyline(slide, pts2, color=line_colors[1], width=1.0)


def draw_bar_chart(slide, x, y, w, h):
    draw_axes(slide, x + 0.1, y + 0.14, w - 0.18, h - 0.24)
    cats = ["RNN", "LSTM", "GRU", "Transformer", "SAETR", "FA-SAETR"]
    pairs = [(0.42, 0.66), (0.49, 0.72), (0.52, 0.81), (0.46, 0.56), (0.75, 0.68), (0.79, 0.84)]
    bar_w = (w - 0.34) / len(cats) * 0.32
    start_x = x + 0.16
    base_y = y + h - 0.12
    chart_h = h - 0.3
    for idx, (mae, rmse) in enumerate(pairs):
        bx = start_x + idx * ((w - 0.34) / len(cats))
        h1 = chart_h * mae
        h2 = chart_h * rmse
        add_rect(slide, bx, base_y - h1, bar_w, h1, "7E98AD", line_hex="5E768A", line_width=0.5)
        add_rect(slide, bx + bar_w + 0.03, base_y - h2, bar_w, h2, "F0C76D", line_hex="C8A450", line_width=0.5)
        add_textbox(slide, bx - 0.05, base_y + 0.02, 0.45, 0.18, [{"text": cats[idx], "size": 8}], margin=0)
    add_textbox(slide, x + 0.78, y - 0.02, 0.36, 0.18, [{"text": "MAE", "size": 9}], fill="7E98AD", line=("5E768A", 0.5, None))
    add_textbox(slide, x + 1.52, y - 0.02, 0.44, 0.18, [{"text": "RMSE", "size": 9}], fill="F0C76D", line=("C8A450", 0.5, None))
    for tick, t in enumerate([0, 50, 100, 150, 200]):
        ty = base_y - tick * chart_h / 4
        add_arrow(slide, x + 0.08, ty, x + 0.1, ty, color="444444", width=0.8, end=None)
        add_textbox(slide, x - 0.12, ty - 0.08, 0.2, 0.16, [{"text": str(t), "size": 8}], align=PP_ALIGN.RIGHT, margin=0)


def draw_scatter(slide, x, y, w, h):
    draw_axes(slide, x + 0.12, y + 0.12, w - 0.22, h - 0.22, xlabel="RUL", ylabel="RUL")
    add_arrow(slide, x + 0.18, y + h - 0.16, x + w - 0.12, y + 0.12, color="666666", width=1.0, end=None)
    add_textbox(slide, x + w - 0.48, y + 0.12, 0.3, 0.16, [{"text": "y=x", "size": 9, "italic": True}], margin=0)
    random.seed(7)
    for i in range(24):
        px = x + 0.22 + (w - 0.42) * (i / 24) * 0.9
        py = y + h - 0.18 - (h - 0.38) * (i / 24) * 0.86 + (random.random() - 0.5) * 0.18
        add_oval(slide, px - 0.025, py - 0.025, 0.05, 0.05, "87A8BE", line_hex="5C7B92", line_width=0.6, transparency=0.05)


def draw_error_analysis(slide, x, y, w, h):
    pane_w = (w - 0.22) / 2
    for i in range(2):
        add_rect(slide, x + i * (pane_w + 0.22), y, pane_w, h, "F7EADC", line_hex="C9AF90", line_width=0.8)
    draw_axes(slide, x + 0.06, y + 0.05, pane_w - 0.1, h - 0.1)
    cdf_pts = []
    for i in range(9):
        px = x + 0.06 + i * (pane_w - 0.12) / 8
        py = y + h - 0.08 - (h - 0.12) * (1 - math.exp(-i / 2.0))
        cdf_pts.append((px, py))
    draw_polyline(slide, cdf_pts, color="6F8FA3", width=1.1)
    add_textbox(slide, x + 0.18, y + h + 0.02, 0.55, 0.18, [{"text": "error CDF", "size": 9}], margin=0)

    x2 = x + pane_w + 0.22
    draw_axes(slide, x2 + 0.06, y + 0.05, pane_w - 0.1, h - 0.1)
    band_low = []
    band_high = []
    mid = []
    for i in range(8):
        px = x2 + 0.06 + i * (pane_w - 0.12) / 7
        mid_y = y + h - 0.08 - (h - 0.14) * (0.08 + 0.08 * i)
        spread = 0.08 + 0.02 * i
        mid.append((px, mid_y))
        band_low.append((px, mid_y + spread))
        band_high.append((px, mid_y - spread))
    for p1, p2 in zip(band_low, band_high):
        add_arrow(slide, p1[0], p1[1], p2[0], p2[1], color="BFD8C9", width=2.0, end=None)
    draw_polyline(slide, mid, color="6E9C95", width=1.1)
    add_textbox(slide, x2 + 0.05, y + h + 0.02, 0.9, 0.18, [{"text": "uncertainty\ncoverage chart", "size": 8}], margin=0)


def draw_feature_importance(slide, x, y, w, h):
    add_textbox(
        slide, x + 0.15, y + 0.03, w - 0.3, 0.22,
        [{"text": "Voltage > Temperature > Current", "size": 11}],
        margin=0,
    )
    labels = ["Voltage", "Temperature", "Current"]
    vals = [0.88, 0.52, 0.34]
    colors = ["7E98AD", "E58A72", "F0C76D"]
    for i, (lab, val, color_hex) in enumerate(zip(labels, vals, colors)):
        yy = y + 0.38 + i * 0.34
        add_textbox(slide, x + 0.05, yy + 0.02, 0.8, 0.18, [{"text": lab, "size": 10}], align=PP_ALIGN.RIGHT, margin=0)
        add_rect(slide, x + 0.92, yy, w * val * 0.62, 0.22, color_hex, line_hex="444444", line_width=0.6)
    add_arrow(slide, x + 0.9, y + h - 0.2, x + w - 0.1, y + h - 0.2, color="222222", width=0.9)


def add_phase1(slide):
    add_phase_container(slide, 0.08, 0.68, 13.84, 2.95, "DDEDED", "Phase I: Data and Feature Engineering")
    panels = [
        (0.22, 1.15, 3.15, 1.75, "MIT Battery Dataset", "E7F0EA"),
        (3.58, 1.15, 3.25, 1.75, "Preprocessing Pipeline", "F7E7DA"),
        (6.95, 1.15, 3.25, 1.75, "Sliding Window\nSample Construction", "DDE7EA"),
        (10.45, 1.15, 3.2, 1.75, "70 Degradation Features", "F7E9C9"),
    ]
    for x, y, w, h, title, fill_hex in panels:
        add_dashed_panel(slide, x, y, w, h, title, fill_hex)

    # Dataset panel
    draw_battery(slide, 0.48, 1.64, fill_hex="C2DDE2")
    draw_battery(slide, 0.84, 1.64, fill_hex="C6D4EC")
    draw_battery(slide, 0.48, 2.17, fill_hex="E5D3A8")
    draw_battery(slide, 0.84, 2.17, fill_hex="D89A86")
    cycle = add_oval(slide, 1.2, 1.6, 0.42, 0.42, "FFFFFF", line_hex="444444", line_width=1.0)
    cycle.fill.background()
    add_textbox(slide, 1.17, 1.67, 0.48, 0.22, [{"text": "cycle", "size": 10, "italic": True}], margin=0)
    draw_clock(slide, 1.18, 2.08, r=0.18)
    draw_tiny_plot(slide, 1.92, 1.55, 0.94, 0.75, bg="FFFFFF")
    add_textbox(slide, 0.52, 2.5, 2.46, 0.22, [{"text": "capacity degradation curves", "size": 10}], margin=0)

    # Preprocessing panel
    draw_clipboard(slide, 3.9, 1.8)
    add_textbox(slide, 4.0, 2.4, 0.35, 0.26, [{"text": "data\ncleaning", "size": 10}], margin=0)
    draw_tiny_plot(slide, 4.73, 1.72, 0.75, 0.62, bg="FFF7F1", line_colors=("9A8AB0", "9E6D67"))
    add_arrow(slide, 4.4, 2.05, 4.68, 2.05, color="222222", width=1.0)
    add_arrow(slide, 5.55, 2.05, 5.83, 2.05, color="222222", width=1.0)
    draw_tiny_plot(slide, 5.88, 1.72, 0.75, 0.62, bg="F7FBFF", line_colors=("9AB0C6", "6D8DA8"))
    add_textbox(slide, 4.55, 2.34, 2.15, 0.35, [{"text": "Savitzky-Golay normalization\nsmoothing", "size": 10}], margin=0)

    # Sliding windows panel
    colors = [("C7DDE1", 0.18), ("E9AB9E", 0.18), ("F1D08A", 0.18), ("D1E3D8", 0.18)]
    starts = [(7.55, 1.52), (7.95, 1.7), (8.35, 1.88), (8.75, 2.06)]
    for (sx, sy), (fill_hex, _) in zip(starts, colors):
        box = add_round_box(slide, sx, sy, 0.74, 0.38, fill_hex, line_hex="444444", line_width=0.8, transparency=0.12)
        try:
            box.fill.transparency = 0.18
        except Exception:
            pass
    add_arrow(slide, 8.15, 1.86, 9.08, 1.86, color="222222", width=1.0)
    add_arrow(slide, 8.55, 2.04, 9.48, 2.04, color="222222", width=1.0)
    add_textbox(slide, 7.45, 2.25, 1.4, 0.36, [{"text": "L = 30\nstride = 10", "size": 10}], margin=0)

    # Features panel
    draw_tiny_plot(slide, 10.67, 1.55, 0.45, 0.34, bg="FFF7F1", line_colors=("C7A28D", "9AAEC1"))
    draw_tiny_plot(slide, 10.67, 1.98, 0.45, 0.34, bg="FFF7F1", line_colors=("D7C2AF", "C7A28D"))
    draw_tiny_plot(slide, 10.67, 2.41, 0.45, 0.34, bg="F7FBFF", line_colors=("8EA8BE", "E5C48D"))
    draw_tiny_plot(slide, 12.82, 1.55, 0.56, 0.34, bg="FFF7F1", line_colors=("C7A28D", "9AAEC1"))
    draw_tiny_plot(slide, 12.78, 2.05, 0.58, 0.52, bg="FFF7F1", line_colors=("C7A28D", "5E768A"))
    draw_clock(slide, 13.1, 2.35, r=0.12)
    add_textbox(
        slide, 11.2, 1.55, 1.5, 1.12,
        [
            {"text": "Capacity/Energy", "size": 10},
            {"text": "Voltage", "size": 10},
            {"text": "Resistance", "size": 10},
            {"text": "Temperature", "size": 10},
            {"text": "Time", "size": 10},
        ],
        align=PP_ALIGN.CENTER,
        margin=1,
    )


def add_phase2(slide):
    add_phase_container(slide, 0.08, 3.92, 13.84, 2.38, "E7EAF6", "Phase II: FA-SAETR Model Architecture")

    # Input sequence
    for i in range(4):
        add_round_box(
            slide,
            0.22 + i * 0.05,
            4.84 - i * 0.07,
            0.46,
            0.42,
            "EFF3F6",
            line_hex="444444",
            line_width=0.9,
            radius_adjust=0.12,
        )
    draw_polyline(
        slide,
        [(0.43, 4.98), (0.5, 4.94), (0.57, 5.01), (0.62, 4.9), (0.69, 4.98)],
        color="7A99AE",
        width=1.0,
    )
    add_textbox(slide, 0.28, 5.28, 0.9, 0.32, [{"text": "Input\nsequence", "size": 10}], margin=0)
    add_arrow(slide, 0.97, 5.0, 1.25, 5.0, color="222222", width=1.1)

    # SE attention
    add_dashed_panel(slide, 1.35, 4.48, 3.9, 1.42, "SE Feature Attention", "EEF4EE")
    bubble = add_oval(slide, 4.12, 4.34, 0.56, 0.24, "F2E1B1", line_hex="444444", line_width=0.8)
    add_textbox(slide, 4.12, 4.35, 0.56, 0.18, [{"text": "Innovation", "size": 9}], margin=0)

    module_specs = [
        (1.48, 4.85, 0.64, 0.74, "DDEAE3", "Global\nAverage\nPooling", 12, 0),
        (2.3, 4.85, 0.28, 0.74, "F0D1CB", "FC", 13, 0),
        (2.76, 4.85, 0.28, 0.74, "CBD7E4", "ReLU", 12, 90),
        (3.28, 4.85, 0.28, 0.74, "F0CF79", "FC", 13, 0),
        (3.76, 4.85, 0.28, 0.74, "CAE5F0", "Sigmoid", 12, 90),
    ]
    for x, y, w, h, fill_hex, text, size, rotation in module_specs:
        shape = add_round_box(slide, x, y, w, h, fill_hex, line_hex="444444", line_width=0.8)
        add_textbox(slide, x + 0.02, y + 0.05, w - 0.04, h - 0.1, [{"text": text, "size": size, "bold": False}], margin=0)
        if rotation:
            shape.rotation = rotation
            shape.text_frame.clear()
            p = shape.text_frame.paragraphs[0]
            p.alignment = PP_ALIGN.CENTER
            run = p.add_run()
            run.text = text
            set_font(run, size=size)
            shape.text_frame.vertical_anchor = MSO_VERTICAL_ANCHOR.MIDDLE
    add_arrow(slide, 2.12, 5.22, 2.28, 5.22, color="222222", width=1.0)
    add_arrow(slide, 2.58, 5.22, 2.74, 5.22, color="222222", width=1.0)
    add_arrow(slide, 3.05, 5.22, 3.26, 5.22, color="222222", width=1.0)
    add_arrow(slide, 3.57, 5.22, 3.74, 5.22, color="222222", width=1.0)
    add_arrow(slide, 4.05, 5.22, 4.38, 5.22, color="222222", width=1.0)
    add_textbox(slide, 4.46, 4.88, 0.72, 0.46, [{"text": "feature\nreweighting", "size": 10}], margin=0)

    # Main backbone
    add_arrow(slide, 5.22, 5.02, 5.56, 5.02, color="222222", width=1.1)
    add_round_box(slide, 5.55, 4.75, 0.22, 0.98, "BFD7D8", line_hex="444444", line_width=0.9)
    add_arrow(slide, 5.78, 5.24, 6.04, 5.24, color="222222", width=1.1)
    add_round_box(slide, 6.08, 4.72, 1.24, 1.02, "7F9DB7", line_hex="444444", line_width=1.0)
    add_textbox(slide, 6.17, 4.93, 1.06, 0.5, [{"text": "Sparse\nAutoencoder", "size": 14, "bold": True}], margin=0)
    add_textbox(slide, 6.28, 5.68, 0.82, 0.18, [{"text": "70 -> 32", "size": 10}], margin=0)

    add_arrow(slide, 7.33, 5.24, 7.72, 5.24, color="222222", width=1.1)
    lp = add_round_box(slide, 7.74, 4.76, 0.46, 0.95, "E48C76", line_hex="444444", line_width=0.9)
    lp.rotation = 90
    lp.text_frame.clear()
    p = lp.text_frame.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    run = p.add_run()
    run.text = "Linear\nProjection"
    set_font(run, size=13, bold=True)
    lp.text_frame.vertical_anchor = MSO_VERTICAL_ANCHOR.MIDDLE
    add_textbox(slide, 7.56, 5.68, 0.86, 0.18, [{"text": "32 -> 128", "size": 10}], margin=0)

    add_arrow(slide, 8.23, 5.24, 8.56, 5.24, color="222222", width=1.1)
    add_oval(slide, 8.54, 4.98, 0.44, 0.44, "F4F4F4", line_hex="444444", line_width=0.9)
    wave = [
        (8.59, 5.21),
        (8.64, 5.09),
        (8.69, 5.27),
        (8.74, 5.11),
        (8.79, 5.25),
        (8.84, 5.12),
        (8.89, 5.22),
    ]
    draw_polyline(slide, wave, color="555555", width=1.0)
    add_textbox(slide, 8.42, 5.38, 0.7, 0.38, [{"text": "Positional\nEncoding", "size": 10}], margin=0)

    add_arrow(slide, 8.99, 5.2, 9.38, 5.2, color="222222", width=1.1)
    add_round_box(slide, 9.45, 4.7, 1.22, 1.0, "EFC96E", line_hex="444444", line_width=1.0)
    add_textbox(slide, 9.54, 4.95, 1.04, 0.44, [{"text": "Transformer\nEncoder", "size": 14, "bold": True}], margin=0)
    add_textbox(slide, 9.45, 5.68, 1.22, 0.18, [{"text": "2 layers, 4 heads", "size": 10}], margin=0)

    add_arrow(slide, 10.68, 5.2, 11.02, 5.2, color="222222", width=1.1)
    add_round_box(slide, 11.02, 4.72, 0.92, 0.96, "F3DDCF", line_hex="444444", line_width=0.9)
    add_textbox(slide, 11.08, 4.96, 0.8, 0.38, [{"text": "Quantile\nHead", "size": 14, "bold": True}], margin=0)
    for idx, q in enumerate(["q0.1", "q0.5", "q0.9"]):
        yy = 4.95 + idx * 0.32
        add_arrow(slide, 11.95, yy + 0.06, 12.12, yy + 0.06, color="222222", width=1.0)
        add_textbox(slide, 12.13, yy - 0.03, 0.34, 0.18, [{"text": q, "size": 10}], align=PP_ALIGN.LEFT, margin=0)

    add_round_box(slide, 12.62, 4.62, 1.44, 1.3, "DCE7D7", line_hex="444444", line_width=0.9)
    add_textbox(slide, 12.72, 4.75, 1.24, 0.46, [{"text": "Side training-\nobjective", "size": 14, "bold": True}], margin=0)
    add_arrow(slide, 12.72, 5.15, 13.94, 5.15, color="777777", width=0.8, end=None)
    add_textbox(
        slide, 12.7, 5.2, 1.26, 0.48,
        [{"text": "Main regression\nloss +\nreconstruction\nloss +\nsparsity loss", "size": 10}],
        margin=0,
    )


def add_phase3(slide):
    add_phase_container(slide, 0.08, 6.52, 13.84, 2.98, "F0F0F0", "Phase III: Evaluation, Interpretation, and Results")

    add_dashed_panel(slide, 0.18, 7.02, 4.06, 1.86, "Performance Comparison Bar Chart", "EEF4EF", title_size=15)
    add_dashed_panel(slide, 4.36, 7.02, 2.56, 1.86, "Predicted vs True RUL\nScatter Plot", "EEF7FF", title_size=15)
    add_dashed_panel(slide, 7.08, 7.02, 3.18, 1.5, "Error analysis charts", "FAEEE7", title_size=15)
    add_dashed_panel(slide, 10.42, 7.02, 3.3, 1.86, "Feature Importance Ranking", "E8EFE6", title_size=15)

    draw_bar_chart(slide, 0.48, 7.6, 3.35, 1.08)
    draw_scatter(slide, 4.72, 7.6, 1.82, 1.08)
    draw_error_analysis(slide, 7.48, 7.47, 2.42, 0.88)
    draw_feature_importance(slide, 10.76, 7.42, 2.62, 1.26)

    add_round_box(
        slide, 7.15, 8.83, 6.44, 0.27, "F4F1E9",
        line_hex="444444",
        line_width=0.8,
        dash=MSO_LINE_DASH_STYLE.DASH,
        radius_adjust=0.18,
    )
    add_textbox(
        slide, 7.22, 8.86, 6.28, 0.18,
        [{"text": "RMSE = 75.29    R^2 = 0.9288    MAE improvement = 21.4%    RMSE improvement = 32.9% vs SAETR", "size": 9}],
        margin=0,
    )


def add_phase_arrows(slide):
    arrow1 = slide.shapes.add_shape(MSO_SHAPE.DOWN_ARROW, Inches(6.78), Inches(3.42), Inches(0.34), Inches(0.55))
    style_fill(arrow1.fill, "111111")
    arrow1.line.fill.background()
    arrow2 = slide.shapes.add_shape(MSO_SHAPE.DOWN_ARROW, Inches(6.78), Inches(6.1), Inches(0.34), Inches(0.55))
    style_fill(arrow2.fill, "111111")
    arrow2.line.fill.background()


def audit_pptx(path):
    with zipfile.ZipFile(path) as archive:
        slide_xml = [
            name for name in archive.namelist()
            if name.startswith("ppt/slides/slide") and name.endswith(".xml")
        ]
        media = [name for name in archive.namelist() if name.startswith("ppt/media/")]

    prs = Presentation(str(path))
    return {
        "path": str(path),
        "size_bytes": path.stat().st_size,
        "slide_count": len(prs.slides),
        "shape_count_per_slide": [len(slide.shapes) for slide in prs.slides],
        "slide_xml_count": len(slide_xml),
        "media_count": len(media),
    }


def build_presentation(output_path, title_text):
    prs = Presentation()
    prs.slide_width = Inches(14)
    prs.slide_height = Inches(10)
    slide = prs.slides.add_slide(prs.slide_layouts[6])

    add_title(slide, title_text)
    add_phase1(slide)
    add_phase2(slide)
    add_phase3(slide)
    add_phase_arrows(slide)

    prs.save(str(output_path))
    return audit_pptx(output_path)


def parse_args():
    parser = argparse.ArgumentParser(description="Build an editable one-slide PPTX flowchart demo.")
    parser.add_argument(
        "--output",
        default=str(Path.cwd() / DEFAULT_OUTPUT_NAME),
        help="Output PPTX path.",
    )
    parser.add_argument(
        "--title",
        default=DEFAULT_TITLE,
        help="Top title text to place on the slide.",
    )
    parser.add_argument(
        "--audit-json",
        default="",
        help="Optional path to write the audit summary as JSON.",
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    output_path = Path(args.output).expanduser().resolve()
    summary = build_presentation(output_path, args.title)
    if args.audit_json:
        audit_path = Path(args.audit_json).expanduser().resolve()
        audit_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
