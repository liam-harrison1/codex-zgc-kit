---
name: flowchart-pptx
description: "Use this skill when the user wants an editable PPTX or PowerPoint flowchart, architecture diagram, pipeline figure, framework overview, or paper figure recreated as shapes instead of a flat image. Trigger on requests mentioning PPTX, PowerPoint, Microsoft PowerPoint, WPS, flowchart, pipeline diagram, architecture diagram, editable slide, one-slide figure reproduction, or recreating a figure from an image into a presentation."
---

# Editable PPTX flowchart workflow

Use this skill to turn a reference figure into a one-slide, editable `.pptx`.

## Preferred execution order

1. Check whether the `ppt` MCP server is available with `codex mcp list`.
2. If `ppt` is available, prefer MCP tools for:
   - presentation creation
   - slide creation
   - shapes
   - connectors
   - text
   - save/export
3. If MCP tools are unavailable in the current tool surface or the task needs lower-level control, use the bundled script at [scripts/build_flowchart_pptx.py](scripts/build_flowchart_pptx.py).
4. If the user explicitly wants WPS validation and WPS exists, open the output in WPS after generation.

## Figure recreation rules

- Do not place the whole source figure on the slide as a single image.
- Rebuild the large structure with shapes, text boxes, connectors, and small vector charts/icons whenever feasible.
- Match the reference aspect ratio before drawing. One slide is the default unless the user asks for more.
- Build from coarse to fine:
  1. canvas and phase containers
  2. inner grouped panels
  3. module boxes and arrows
  4. labels and subtitles
  5. mini charts, icons, and annotations
- Keep text editable. Avoid rasterizing labels.

## Recommended MCP tool sequence

When using the `ppt` MCP server, the usual order is:

1. `create_presentation`
2. `add_slide`
3. `add_shape`
4. `add_connector`
5. `manage_text`
6. `save_presentation`

For layout-heavy figures, first create all containers and connectors, then run text insertion, then do a final pass for spacing and styling.

More detail: see [references/ppt-mcp.md](references/ppt-mcp.md).

## Bundled fallback script

The bundled script is useful when:

- the current session cannot call the new MCP server yet
- exact shape placement is easier to express in Python
- you need an auditable result

Run it like this from the target workspace:

```bash
PYTHONPATH='./.vendor-pptx' python3 /absolute/path/to/build_flowchart_pptx.py \
  --output /absolute/path/to/output.pptx \
  --audit-json /absolute/path/to/output.audit.json
```

The script prints a JSON summary with:

- output path
- file size
- slide count
- shape count per slide
- `ppt/media` count

Use that summary to confirm the result is still shape-based and not a full-slide image export.

## WPS / PowerPoint verification

If the user cares about WPS or PowerPoint compatibility:

- WPS on this machine is at `/Applications/wpsoffice.app`
- open with:

```bash
open -a /Applications/wpsoffice.app /absolute/path/to/output.pptx
```

- verify the file opens and, if needed, check with `lsof /absolute/path/to/output.pptx`

## Final checks

- confirm the requested output path
- confirm slide count
- confirm whether embedded media is acceptable
- if the user asked for "not an image", mention the `ppt/media` audit result
