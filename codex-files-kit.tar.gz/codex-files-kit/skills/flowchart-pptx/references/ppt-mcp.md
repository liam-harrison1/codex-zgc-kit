# PPT MCP notes

Current preferred MCP:

- repo: `GongRzhe/Office-PowerPoint-MCP-Server`
- local server name: `ppt`
- registered command:

```bash
uvx --from office-powerpoint-mcp-server ppt_mcp_server
```

Template path env:

```bash
PPT_TEMPLATE_PATH=/Users/lzc/Documents/科研/电池
```

Useful capabilities from the server README:

- `create_presentation`
- `add_slide`
- `add_shape`
- `add_connector`
- `manage_text`
- `save_presentation`
- template-aware generation
- chart and table support

Recommended use for editable flowchart work:

1. create one presentation
2. create one blank slide
3. add the outer containers first
4. add inner grouped panels
5. add connectors and arrows
6. add text
7. save

Fallback rule:

- if the MCP is connected but not callable from the current session, use the local Python script and still report that the `ppt` MCP has been configured for future runs
